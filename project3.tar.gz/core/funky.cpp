/*
                                   


                                 **********************************                       
                                 +   Project: 3                   +
                                 +   First Name: Omar             +
                                 +   Last Name: Saleh             +
                                 +   ID# 38995711                 +
                                 +   UCI ID: saleho               +
                                 +   UCI E-mail: saleho@uci.edu   +
                                 **********************************



*/



#include <ics46/factory/DynamicFactory.hpp>
#include "funky.hpp"
#include <string>
#include <cmath>
#include <memory>
ICS46_DYNAMIC_FACTORY_REGISTER(OthelloAI, saleho::funky, "FunkyAI(Required)");


namespace saleho //start namespace saleho
{




bool funky::taken(const int width, const int height, const OthelloGameState &curr,OthelloCell curr_turn)
{
    bool flag = true;
    if(curr.board().cellAt(width,height) != curr_turn)
    {
        flag = false;
    }
    else
    {
        flag = true;
    }
    return flag;
}



//evaluation function
int funky::evaluation(OthelloCell active_color, const OthelloGameState &active_box)
{
    int starting_capture = 0;
    int active_captures = 0;
    bool orig = false;
    bool other = false;
    int eva = 10;
    OthelloCell color;

    if(active_color == OthelloCell::white)
    {
        color = OthelloCell::black;
    }
    else if(active_color == OthelloCell::black)
    {
        color = OthelloCell::white;
    }
    color = OthelloCell::empty; // if it is not black or white then set color to empty empty      

    if(taken(1, active_box.board().height()-2,active_box, active_color) ||taken(0, active_box.board().height()-1,active_box, active_color)||taken(1, active_box.board().height()-1,active_box, active_color)||taken(0, active_box.board().height()-2,active_box, active_color)||taken(active_box.board().width()-2, 0,active_box, active_color) ||taken(active_box.board().width()-2, 1,active_box, active_color) ||taken(active_box.board().height()-2, active_box.board().width()-2,active_box, active_color) ||
       taken(active_box.board().height()-1, active_box.board().width()-2,active_box, active_color) || taken(active_box.board().width()-1, 1,active_box, active_color)||taken(0, 1,active_box, active_color) ||taken(active_box.board().width()-1, 0,active_box, active_color) ||taken(active_box.board().width()-1, active_box.board().height()-1,active_box, active_color)||taken(active_box.board().height()-2, active_box.board().width()-1,active_box, active_color))
    {
        orig = true;
    }
    else
    {
        orig = false; 
    }

    if(taken(active_box.board().height()-2, active_box.board().width()-2,active_box, color) || taken(0, active_box.board().height()-1,active_box, color)||taken(active_box.board().height()-2, active_box.board().width()-1,active_box, color) ||taken(active_box.board().width()-2, 1,active_box, color) ||taken(active_box.board().width()-1, 1,active_box, color) ||taken(0, active_box.board().height()-2,active_box, color) ||
       taken(1, active_box.board().height()-2,active_box, color) ||taken(1, active_box.board().height()-1,active_box, color) || taken(active_box.board().height()-1, active_box.board().width()-2,active_box, color)||taken(active_box.board().width()-2, 0,active_box, color) ||taken(0, 1,active_box, color) ||taken(active_box.board().width()-1, 0,active_box, color))
    {
        other = true;
    }
    else
    {
        other = false;
    }
    if(orig == true)
    {
        return (eva*-1);
    }else if ( other == true) 
    {
        return eva;
    }
    for (int i = 2; i < (active_box.board().width()-1);++i)
    {        
        if (active_box.board().cellAt(i, 0) == active_color)
        {
            ++starting_capture;        
        }
        else if (active_box.board().cellAt(i, active_box.board().height()-1) == active_color)
        {
            ++starting_capture;
        }
    }
    for (int i = 2; i < (active_box.board().width()-1);++i)
    {        
        if (active_box.board().cellAt(i, 0) == color)
        {
            ++active_captures;        
        }
        else if (active_box.board().cellAt(i, (active_box.board().height()-1)) == color)
        {
            ++active_captures;
        }
    }
    for (int i = 2; i < active_box.board().height()-1;++i)
    {        
        if (active_box.board().cellAt(0, i) == active_color)
        {
            ++starting_capture;    
        }
        else if (active_box.board().cellAt((active_box.board().width()-1), i) == active_color)
        {
            ++starting_capture;
        }
    }
    for (int i = 2; i < (active_box.board().height()-1);++i)
    {        
        if (active_box.board().cellAt(0, i) == color)
        {
            ++active_captures;    
        }
        else if (active_box.board().cellAt((active_box.board().width()-1), i) == color)
        {
            ++active_captures;
        }
    }
    return (starting_capture - active_captures);
}




int funky::find(const int tree_depth, OthelloGameState& active_box, OthelloCell active_color)
{
    int bad= 11;
    int good= (-11); 
    int test =0; 
    std::unique_ptr<OthelloGameState> plus;         
    OthelloCell current_turn;
    int eva = 0;

    if (active_box.isWhiteTurn()) //keeps track of box color
    {
        current_turn= OthelloCell::white;
    }
    else
    {
        current_turn = OthelloCell::black;
    }

    if(tree_depth >= 2)
    {
         if(active_color != current_turn) 
         { 
            for (int i=0; i <= (active_box.board().width()-1); ++i)
            {for (int j= 0; j <= (active_box.board().height()-1); ++j)
            {
                if (active_box.isValidMove(i, j))
                {
                    plus = active_box.clone();
                    plus-> makeMove( i, j );
                    test = find((tree_depth-1),*plus, active_color);
                    bad = std::min(bad, test);
                }
            }
            }
            eva = bad;
            return eva;
        }
        else if (active_color == current_turn)
        {    
            for (int i=0; i <= (active_box.board().width()-1); ++i)
            {for (int j=0; j <= (active_box.board().height()-1); ++j)
            {
                if (active_box.isValidMove(i, j))
                {
                      plus = active_box.clone();
                     plus-> makeMove( i, j );
                    test = find((tree_depth-1), *plus, active_color);
                     good = std::max(good, test);
                    }
                }
            }
            eva = good;
            return eva;
        }
    }
eva = evaluation(active_color, active_box);

return eva;
}





//main function
std::pair<int, int> funky::chooseMove(const OthelloGameState &x)
{
    std::pair<int, int> move_location;
    move_location = {0,0};
    const int tree_d =2; //depth of the imaginary tree
    int move_rating = (-20);    
    int test =0; 
    std::unique_ptr<OthelloGameState> active_box;
    OthelloCell my_color; //the color the AI is playing with

    if ( x.isWhiteTurn() == true ) //saves the color the AI is playing with
    {
        my_color = OthelloCell::white;
    }
    else if( x.isBlackTurn() == true)
    {
        my_color = OthelloCell::black;
    }

for (int i= 0; i < x.board().width();++i)
{
    for (int j=0; j < x.board().height();++j)
    {if (x.isValidMove(i, j))
    {                
        active_box= x.clone();
        active_box-> makeMove( i , j );
        test = find(tree_d,*active_box, my_color);
    if(test >= (move_rating + 1))
    {
        move_rating= test;
        move_location= std::pair<int,int>{ i , j };
    }
    }

    }
}    
    return move_location;
}

}//end namespace saleho