/*
                                   


                                 **********************************                       
                                 +   Project: 3                   +
                                 +   First Name: Omar             +
                                 +   Last Name: Saleh             +
                                 +   ID# 38995711                 +
                                 +   UCI ID: saleho               +
                                 +   UCI E-mail: saleho@uci.edu   +
                                 **********************************



*/


#include "OthelloAI.hpp"
#ifndef FUNKY_HPP
#define FUNKY_HPP

namespace saleho
{
    class funky:public OthelloAI
    {
    public:
        bool taken(const int width, const int height, const OthelloGameState &curr,OthelloCell curr_turn);
        int evaluation(OthelloCell active_color, const OthelloGameState &active_box);
        int find(const int tree_depth, OthelloGameState& active_box, OthelloCell active_color);
        virtual std::pair<int, int> chooseMove(const OthelloGameState &x);  // main function          
    };
    #endif
}